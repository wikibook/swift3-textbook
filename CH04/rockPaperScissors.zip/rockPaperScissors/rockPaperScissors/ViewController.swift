//
//  ViewController.swift
//  rockPaperScissors
//
//  Created by YoonGahee on 2016. 8. 2..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit
import GameplayKit

class ViewController: UIViewController {
    let randomSource = GKARC4RandomSource()

    @IBOutlet weak var computerImageView: UIImageView!
    @IBOutlet weak var playerImageView: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 180도의 라디안을 구합니다.
        let angle:CGFloat = CGFloat((180.0 * M_PI) / 180.0)
        // 이미지 뷰를 회전시킵니다.
        computerImageView.transform = CGAffineTransform(rotationAngle: angle)
    }

    @IBAction func tapStart() {
        // 이미지 뷰에 바위를 출력합니다.
        computerImageView.image = UIImage(named: "rock.png")
        playerImageView.image = UIImage(named: "rock.png")
        // 레이블에 "가위 바위...."를 출력합니다.
        messageLabel.text = "가위 바위...."
    }
    
    @IBAction func tapScissors() {
        playerImageView.image = UIImage(named: "scissors.png")
        doComputer(player: 0)
    }
    @IBAction func tapRock() {
        playerImageView.image = UIImage(named: "rock.png")
        doComputer(player: 1)
    }
    @IBAction func tapPaper() {
        playerImageView.image = UIImage(named: "paper.png")
        doComputer(player: 2)
    }
    
    func doComputer(player:Int) {
        // 0~2 범위의 랜덤 값을 구합니다.
        let computer = randomSource.nextInt(upperBound: 3)
        // 승패 판정 전용 문자열을 준비합니다.
        var msg = ""
        
        switch computer {
        case 0:
            // 가위
            computerImageView.image = UIImage(named: "scissors.png")
            
            switch player {
            case 0: // 가위
                msg = "비겼어요!"
            case 1: // 바위
                msg = "이겼어요....!"
            case 2: // 보
                msg = "졌어요ㅠㅁㅜ"
            default:
                break
            }
        case 1:
            // 바위
            computerImageView.image = UIImage(named: "rock.png")
            
            switch player {
            case 0: // 가위
                msg = "졌어요ㅠㅁㅜ"
            case 1: // 바위
                msg = "비겼어요!"
            case 2: // 보
                msg = "이겼어요....!"
            default:
                break
            }
        case 2:
            // 보
            computerImageView.image = UIImage(named: "paper.png")
            
            switch player {
            case 0: // 가위
                msg = "이겼어요....!"
            case 1: // 바위
                msg = "졌어요ㅠㅁㅜ"
            case 2: // 보
                msg = "비겼어요!"
            default:
                break
            }
        default:
            break
        }
        
        messageLabel.text = msg
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

