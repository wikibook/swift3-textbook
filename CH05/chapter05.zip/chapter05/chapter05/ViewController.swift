//
//  ViewController.swift
//  chapter05
//
//  Created by YoonGahee on 2016. 8. 9..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit
// SFSafariViewController 사용 준비
import SafariServices
// Social 사용 준비
import Social

class ViewController: UIViewController, SFSafariViewControllerDelegate {
    @IBOutlet weak var myWebView: UIWebView!
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBAction func tapShareBtn() {
        /*
        // 공유할 문자를 배열에 넣습니다.
        let shareText = "글을 써봐요!"
        let shareItems = [shareText]
        // 공유 액션 시트를 생성하고 배열을 매개 변수로 넣음
        let avc = UIActivityViewController(activityItems: shareItems, applicationActivities: nil)
        // 공유 액션 시트 출력
        present(avc, animated: true, completion: nil)
        */
        
        // 공유할 문자를 배열에 넣습니다.
        let shareText = "글을 써봐요!"
        let shareItems = [shareText]
        // 공유 액션 시트를 생성하고 excludedActivityTypes 지정
        let avc = UIActivityViewController(activityItems: shareItems, applicationActivities: nil)
        avc.excludedActivityTypes = [
            UIActivityTypeSaveToCameraRoll,
            UIActivityTypeAirDrop,
            UIActivityTypeAssignToContact,
            UIActivityTypeAddToReadingList
        ]
        // 공유 액션 시트 출력
        present(avc, animated: true, completion: nil)
    }
    
    @IBAction func tapTwitterBtn() {
        // 트위터 글쓰기 대화 상자 생성
        let cv = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
        // 기본적으로 들어갈 글자 설정
        cv?.setInitialText("글을 써봐요")
        // 글쓰기 대화상자 출력
        self.present(cv!, animated: true, completion: nil)
    }
    
    @IBAction func tapLoadText2() {
        // 버튼을 눌렀을 때
        if let url = URL(string: "https://wikibook.github.io/swift3-textbook/test.txt") {
            // url이 nil이 아니라면 URLSession 객체 생성
            let urlSession = URLSession.shared
            // 데이터를 읽어들이는 태스크를 완료하면 completionHandler 처리가 수행됩니다.
            let task = urlSession.dataTask(with: url, completionHandler: onFinish)
            task.resume()
        }
    }
    
    // 읽어들이기를 완료했을 때 호출할 메서드 생성(이름은 자유)
    func onFinish(data: Data?, response: URLResponse?, error: NSError?) {
        // Raw 데이터를 UTF8 문자열로 변환
        if let nsstr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue) {
            // UTF8 문자열로 변환되면 일반적인 문자열로 변환
            let str = String(nsstr)
            // 문자열 출력
            print("문자열=[\(str)]")
        }
    }
    
    @IBAction func tapLoadText1() {
        // 버튼을 눌렀을 때
        if let url = URL(string: "https://wikibook.github.io/swift3-textbook/test.txt") {
            // url이 nil이 아니라면 URLSession 객체 생성
            let urlSession = URLSession.shared
            // 데이터를 읽어들이는 태스크를 완료하면 completionHandler 처리가 수행됩니다.
            let task = urlSession.dataTask(with: url, completionHandler: {
                (data, response, error) in
                // Raw 데이터를 UTF8 문자열로 변환
                if let nsstr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue) {
                    // UTF8 문자열로 변환되면 일반적인 문자열로 변환
                    let str = String(nsstr)
                    // 문자열 출력
                    print("문자열=[\(str)]")
                }
            })
            task.resume()
        }
    }
    
    @IBAction func tapLoadImage() {
        // 버튼을 눌렀을 때
        let stringURL = "https://wikibook.github.io/swift3-textbook/sample.jpg"
        if let url = URL(string: stringURL) {
            // url이 nil이 아니라면 변환
            if let data = NSData(contentsOf: url) {
                // 변환된 data를 출력
                myImageView.image = UIImage(data: data as Data)
            }
        }
    }
    @IBAction func tapBtn() {
        // 버튼을 눌렀을 때
        if let url = URL(string: "http://www.apple.com/kr") {
            // url이 nil이 아니라면 SFSafariViewController를 출력
            let vc = SFSafariViewController(url: url)
            vc.delegate = self
            present(vc, animated: true, completion: nil)
        }
    }
    
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        print("Close")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let stringURL = "http://www.google.co.kr"
        if let url = URL(string: stringURL) {
            // url이 nil이 아니라면 출력합니다.
            let urlreq = URLRequest(url: url)
            myWebView.loadRequest(urlreq)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

