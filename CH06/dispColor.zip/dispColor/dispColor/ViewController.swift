//
//  ViewController.swift
//  dispColor
//
//  Created by YoonGahee on 2016. 8. 24..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit
// 랜덤 사용 준비
import GameplayKit

class ViewController: UIViewController {
    @IBOutlet weak var colorLabel: UILabel!
    
    // 랜덤 사용 준비
    let randomSource = GKARC4RandomSource()
    var colorR = 0
    var colorG = 0
    var colorB = 0
    
    override func viewWillAppear(_ animated: Bool) {
        // 0~255 범위의 랜덤한 숫자 3개를 구합니다.
        colorR = randomSource.nextInt(upperBound: 256)
        colorG = randomSource.nextInt(upperBound: 256)
        colorB = randomSource.nextInt(upperBound: 256)
        // 3개의 값을 출력합니다.
        colorLabel.text = "R=\(colorR), G=\(colorG), B=\(colorB)"
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // 변경될 화면을 추출합니다.
        let nextvc = segue.destination as! ColorViewController
        // 변경될 화면에 있는 변수에 값을 전달합니다.
        nextvc.colorR = colorR
        nextvc.colorG = colorG
        nextvc.colorB = colorB
    }
    
    @IBAction func returnTop(segue: UIStoryboardSegue) {
        
    }
}

