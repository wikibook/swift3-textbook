//
//  SecondViewController.swift
//  convertUnit
//
//  Created by YoonGahee on 2016. 8. 24..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var dataTextField: UITextField!
    
    // AppDelegate에 접근할 수 있게 객체를 만듭니다.
    let ap = UIApplication.shared().delegate as! AppDelegate
    // 화면을 출력할 때 호출됩니다.
    override func viewWillAppear(_ animated: Bool) {
        // 공유 변수의 값을 텍스트 필드에 설정합니다.
        let inchValue = ap.cmValue * 0.3937
        dataTextField.text = String(inchValue)
    }
    
    @IBAction func tapInput() {
        // 키보드를 닫습니다.
        dataTextField.resignFirstResponder()
        if let text = dataTextField.text {
            // 텍스트 필드에 값이 있을 때
            if let inchValue = Double(text) {
                // 부동 소수 값으로 변환할 수 있다면, cm로 변환해서 공유 변수에 값을 적습니다.
                ap.cmValue = inchValue / 0.3937
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

