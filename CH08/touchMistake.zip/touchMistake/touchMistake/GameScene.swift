//
//  GameScene.swift
//  touchMistake
//
//  Created by YoonGahee on 2016. 8. 25..
//  Copyright © 2016년 myname. All rights reserved.
//

import SpriteKit
// 랜덤을 사용하기 위한 준비
import GameplayKit

class GameScene: SKScene {
    // 랜덤을 사용하기 위한 준비
    let randomSource = GKARC4RandomSource()
    // 다른 번호를 나타내는 변수를 준비합니다.
    var mistakeNo = 0
    
    // 메시지를 출력할 레이블 노드를 만듭니다.
    let msgLabel = SKLabelNode(fontNamed: "AppleGothic")
    var msg:String = "다른 글자를 터치해주세요."
    // 공의 갯수를 6개로 설정합니다.
    let ballMax = 6
    // 공을 넣을 배열을 준비합니다.
    var ballList:[SKShapeNode] = []
    
    // 문제를 배열로 준비합니다.
    let correct = [
        "가", "교", "뷁", "궭", "굼",
        "동", "귥", "곪", "갊", "핡",
        "훑", "굙", "놃", "솗", "돏",
        "쥛", "줼", "콩", "맓", "칿"]
    let mistake = [
        "갸", "고", "뷃", "궯", "궁",
        "돔", "굵", "곫", "갉", "핥",
        "홂", "귥", "놂", "솖", "돎",
        "쥜", "좰", "쿙", "밟", "캷"]
    // 문제 번호 변수를 준비합니다.
    var questionNo = 0
    
    override func didMove(to view: SKView) {
        // 배경을 흰색으로 설정합니다.
        self.backgroundColor = UIColor.white
        // 메시지 레이블을 출력합니다.
        msgLabel.text = msg
        msgLabel.fontSize = 36
        msgLabel.fontColor = UIColor.red
        msgLabel.position = CGPoint(x: 320, y: 1080)
        self.addChild(msgLabel)
        
        newQuestion()
    }
    
    // 문제를 만드는 메서드
    func newQuestion() {
        // 문제 번호를 결정합니다.
        questionNo = randomSource.nextInt(upperBound: correct.count)
        // 다른 문자를 적을 공의 번호를 정합니다.
        mistakeNo = randomSource.nextInt(upperBound: ballMax)
        
        // 공 배열을 비웁니다.
        ballList = []
        // ballMax 개의 공을 만듭니다.
        for loopID in 0 ..< ballMax {
            // 셰이프 노드로 공을 만듭니다.
            let ball = SKShapeNode(circleOfRadius: 45)
            ball.fillColor = UIColor(red: 1.0, green: 0.9, blue: 0.6, alpha: 1.0)
            ball.position = CGPoint(x: loopID * 100 + 70, y: 1000)
            // 씬에 출력합니다.
            self.addChild(ball)
            // 공 배열에 추가합니다.
            ballList.append(ball)
            
            // 문자를 출력할 레이블 노드를 만듭니다.
            let text = SKLabelNode(fontNamed: "AppleGothic")
            // 문제를 설정합니다.
            if loopID != mistakeNo {
                // 일반 문자를 출력합니다.
                text.text = correct[questionNo]
            } else {
                // 틀린 문자를 출력합니다.
                text.text = mistake[questionNo]
            }
            text.fontSize = 60
            text.fontColor = UIColor.black
            text.position = CGPoint(x: 0, y: -23)
            // 공에 문자를 추가합니다.
            ball.addChild(text)
            
            // 0초 동안 화면의 위로 이동하는 움직임
            let action1 = SKAction.moveTo(y: 1300, duration: 0)
            // 랜덤한 시간만큼 대기하는 움직임
            let wait = SKAction.wait(forDuration: 1.0, withRange: 2.0)
            // 랜덤한 시간동안 화면 아래로 이동하는 움직임
            let randomSec = Double(randomSource.nextInt(upperBound: 30)) / 10.0 + 3.0
            let action2 = SKAction.moveTo(y: -100, duration: randomSec)
            // 이러한 움직임을 순서대로 재생하는 움직임
            let actionSequence = SKAction.sequence([action1, wait, action2])
            // 이를 계속 반복하게 만드는 움직임
            let actionRepeat = SKAction.repeatForever(actionSequence)
            // 공에 움직임을 설정합니다.
            ball.run(actionRepeat)
        }
    }
    
    // 정답을 확인하는 메서드
    func answerCheck(no: Int) {
        // 정답인지 판정하고 결과를 출력합니다.
        if no == mistakeNo {
            msg = "맞았어요! \(correct[questionNo])와 \(mistake[questionNo])였답니다."
        } else {
            msg = "틀렸어요! \(correct[questionNo])와 \(mistake[questionNo])였답니다."
        }
        msgLabel.text = msg
        // 화면에 있는 모든 공 제거
        for loopID in 0 ..< ballMax {
            ballList[loopID].removeFromParent()
        }
        // 다음 문제 생성
        newQuestion()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // 터치 정보를 추출합니다.
        for touch in touches {
            // 터치한 위치에 있는 모든 노드를 추출합니다.
            let location = touch.location(in: self)
            let touchNodes = self.nodes(at: location)
            // 노드를 모두 확인합니다.
            for touchNode in touchNodes {
                // 공 배열과 비교해서
                for loopID in 0 ..< ballMax {
                    // 터치한 노드가 공이라면
                    if touchNode == ballList[loopID] {
                        answerCheck(no: loopID)
                        break
                    }
                }
            }
        }
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}














