//
//  GameScene.swift
//  sampleGame
//
//  Created by YoonGahee on 2016. 8. 24..
//  Copyright © 2016년 myname. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    override func didMove(to view: SKView) {
        // CHAPTER 8-9 2D 물리 시뮬레이션
        // 물리 시뮬레이션 공간을 화면 크기에 맞게 생성합니다.
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        // 셰이프 노드로 공을 만듭니다.
        let ball = SKShapeNode(circleOfRadius: 50)
        // 공의 색상을 지정합니다.
        ball.fillColor = UIColor.cyan
        // 공의 위치를 잡습니다.
        ball.position = CGPoint(x: 320, y: 800)
        // 공을 출력합니다.
        self.addChild(ball)
        // 셰이프 노드에 물리 시뮬레이션을 적용합니다.
        ball.physicsBody = SKPhysicsBody(circleOfRadius: 50)
        
        
        
        // CHAPTER 8-7 사용자 터치 확인
        // 멀티 터치 기능 활성화
        // self.view?.isMultipleTouchEnabled = true
        
        // CHAPTER 8-6 움직임 조합
        /*
        // 스프라이트 생성
        let mySprite = SKSpriteNode(imageNamed: "wiki.png")
        // 위치 지정
        mySprite.position = CGPoint(x: 320, y: 500)
        // 스프라이트 출력
        addChild(mySprite)
        
        // 360도 회전하는 움직임 생성
        //let action = SKAction.rotate(byAngle: CGFloat(360 * M_PI / 180), duration: 1)
        // 3회 반복하는 움직임 생성
        //let actionRepeat = SKAction.repeat(action, count: 3)
        // 계속 반복하는 움직임 생성
        //let actionRepeat = SKAction.repeatForever(action)
        // 움직임 적용
        //mySprite.run(actionRepeat)
        
        // 360도 회전하는 움직임 생성
        //let action1 = SKAction.rotate(byAngle: CGFloat(360 * M_PI / 180), duration: 1)
        // 400, 400으로 이동하는 움직임 생성
        //let action2 = SKAction.move(to: CGPoint(x: 400, y:400), duration: 1)
        // 2개의 움직임을 동시에 실행하는 움직임 생성
        //let actionGroup = SKAction.group([action1, action2])
        // 움직임 적용
        //mySprite.run(actionGroup)
        
        // 360도 회전하는 움직임 생성
        //let action1 = SKAction.rotate(byAngle: CGFloat(360 * M_PI / 180), duration: 1)
        // 400, 400으로 이동하는 움직임 생성
        //let action2 = SKAction.move(to: CGPoint(x: 400, y:400), duration: 1)
        // 2개의 움직임을 차례대로 실행하는 움직임 생성
        //let actionSequence = SKAction.sequence([action1, action2])
        // 움직임 적용
        //mySprite.run(actionSequence)
        
        // 360도 회전하는 움직임 생성
        let action1 = SKAction.rotate(byAngle: CGFloat(360 * M_PI / 180), duration: 1)
        // 1초 동안 대기하는 움직임 생성
        //let wait = SKAction.wait(forDuration: 1)
        // 랜덤한 시간동안 대기하는 움직임 생성
        let waitRandom = SKAction.wait(forDuration: 1.0, withRange: 2.0)
        // 400, 400으로 이동하는 움직임 생성
        let action2 = SKAction.move(to: CGPoint(x: 400, y:400), duration: 1)
        // 2개의 움직임을 차례대로 실행하는 움직임 생성
        let actionSequence = SKAction.sequence([action1, waitRandom, action2])
        // 움직임 적용
        mySprite.run(actionSequence)
        */
        
    
        
        
        
        // CHAPTER 8-5 스프라이트에 움직임 적용
        /*
        // 스프라이트 생성
        let mySprite = SKSpriteNode(imageNamed: "wiki.png")
        // 위치 지정
        mySprite.position = CGPoint(x: 100, y: 100)
        // 스프라이트 출력
        addChild(mySprite)
        
        // 지정한 위치로 이동하는 움직임 생성
        //let action = SKAction.move(to: CGPoint(x: 500, y: 500), duration: 1)
        
        // 지정한 만큼 이동하는 움직임 생성
        //let action = SKAction.move(by: CGVector(dx: 300, dy: 500), duration: 1)
        
        // 지정한 만큼 회전하는 움직임 생성
        //let action = SKAction.rotate(toAngle: CGFloat(45 * M_PI / 180), duration: 1)
        
        // 지정한 만큼 추가로 회전하는 움직임 생성
        //let action = SKAction.rotate(byAngle: CGFloat(60 * M_PI / 180), duration: 1)
        
        // 지정한 배율로 확대/축소하는 움직임 생성
        //let action = SKAction.scale(to: 3, duration: 1)
        
        // 지정한 크기로 확대/축소하는 움직임 생성
        //let action = SKAction.resize(toWidth: 100, height: 100, duration: 1)
        
        // 지정한 만큼 이동하는 움직임 생성
        let action = SKAction.move(by: CGVector(dx: 300, dy: 500), duration: 1)
        // 점점 느려지게 가속 적용
        action.timingMode = SKActionTimingMode.easeOut
        
        // 움직임 적용
        mySprite.run(action)
        */
        
        
        
        
        // CHAPTER 8-4 파티클
        /*
        // 파티클 시스템으로 이미터 생성
        if let myEmitter = SKEmitterNode(fileNamed: "MyParticle.sks") {
            // 이미터의 위치 지정
            myEmitter.position = CGPoint(x: 320, y: 400)
            // 이미터 출력
            self.addChild(myEmitter)
        }
        */
        
        
        
        
        // CHAPTER 8-3 객체 출력: 레이블, 스프라이트, 셰이프
        /*
        let myLabel = SKLabelNode(text: "Hello")
        myLabel.text = "Hello World"
        myLabel.fontName = "Papyrus"
        myLabel.fontSize = 36
        myLabel.fontColor = UIColor.blue()
        myLabel.position = CGPoint(x: 100, y: 100)
        self.addChild(myLabel)
        
        //let mySprite = SKSpriteNode(imageNamed: "wiki.png")
        
        let myTexture = SKTexture(imageNamed: "wiki.png")
        let mySprite = SKSpriteNode(texture: myTexture, size: CGSize(width: 350, height: 350))
        mySprite.size = CGSize(width: 200, height: 200)
        mySprite.position = CGPoint(x: 100, y: 400)
        self.addChild(mySprite)
        
        let myCircleShape = SKShapeNode(circleOfRadius: 20)
        let myRectShape = SKShapeNode(rectOf: CGSize(width: 100, height: 50))
        myCircleShape.fillColor = UIColor.yellow()
        myRectShape.strokeColor = UIColor.red()
        myRectShape.lineWidth = 2
        myCircleShape.position = CGPoint(x: 100, y: 600)
        myRectShape.position = CGPoint(x: 100, y: 800)
        self.addChild(myCircleShape)
        self.addChild(myRectShape)
        
        // 'Hello'라는 레이블 노드 출력
        let myLabel = SKLabelNode(text: "Hello")
        myLabel.position = CGPoint(x: 50, y: 50)
        myLabel.fontSize = 48
        self.addChild(myLabel)
 
        // 크기가 반경 50인 원을 나타내는 셰이프 노드 위에 'Hello' 레이블 노드를 추가해서 출력
        let myShape = SKShapeNode(circleOfRadius: 50)
        myShape.fillColor = UIColor.blue()
        let myLabel2 = SKLabelNode(text: "Hello")
        myShape.addChild(myLabel2)
        self.addChild(myShape)
        myShape.position = CGPoint(x: 320, y: 320)
        */
    }
    
    // 사용자가 터치했을 때 호출
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // 터치 정보 추출
        for touch in touches {
            // 씬에서의 위치 추출
            let location = touch.location(in: self)
            // 해당 위치에 있는 노드 확인
            let touchNodes = self.nodes(at: location)
            // 노드 확인
            for touchNode in touchNodes {
                // 위치 출력
                print(touchNode)
            }
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}













