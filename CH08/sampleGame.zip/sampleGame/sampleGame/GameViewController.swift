//
//  GameViewController.swift
//  sampleGame
//
//  Created by YoonGahee on 2016. 8. 24..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 640x1136 크기의 게임 씬을 만듭니다.
        let scene = GameScene(size: CGSize(width: 640, height: 1136))
        // Main.storyboard의 View를 SKView로 변환합니다.
        let skView = self.view as! SKView
        // 화면 모드를 화면 크기에 맞게 확대축소하는 모드로 설정합니다.
        scene.scaleMode = .aspectFit
        // SKView에 씬을 출력합니다.
        skView.presentScene(scene)
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
}
