//
//  MasterViewController.swift
//  photoCatalog
//
//  Created by YoonGahee on 2016. 8. 24..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    var detailViewController: DetailViewController? = nil
    // 초기 데이터
    var objects = [
        "fireworks001", "fireworks002", "fireworks003", "fireworks004",
        "fireworks005", "fireworks006", "fireworks007"]


    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 마스터 화면의 타이틀 문자
        self.title = "불꽃놀이 목록"
    }

    override func viewWillAppear(_ animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                // 문자열 데이터로 수정
                let object = objects[indexPath.row]
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = object as AnyObject?
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Table View

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objects.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        // 문자열 데이터로 수정
        let object = objects[indexPath.row]
        // 문자열 데이터로 수정
        cell.textLabel!.text = object
        return cell
    }
}

