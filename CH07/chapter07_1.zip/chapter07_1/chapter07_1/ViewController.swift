//
//  ViewController.swift
//  chapter07_1
//
//  Created by YoonGahee on 2016. 8. 24..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // 사용자 정의 셀 객체 생성
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        
        // 태그 번호로 객체에 접근
        if let label = cell.viewWithTag(1) as? UILabel {
            label.text = "안녕하세요!"
        }
        
        return cell
    }

}

