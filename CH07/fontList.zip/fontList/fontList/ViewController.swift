//
//  ViewController.swift
//  fontList
//
//  Created by YoonGahee on 2016. 8. 24..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    // 폰트 이름을 넣을 배열(문자열 자료형 배열)을 준비합니다.
    var fontNameArray:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 폰트 패밀리 이름을 모두 탐색합니다.
        for fontFamilyName in UIFont.familyNames() {
            // 해당 폰트 패밀리를 기반으로 폰트를 탐색합니다.
            for fontName in UIFont.fontNames(forFamilyName: fontFamilyName as String) {
                // 폰트 이름을 배열에 넣습니다.
                fontNameArray.append(fontName as String)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fontNameArray.count
    }
    
    // 셀에 출력할 내용을 정의합니다.
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // 셀을 만듭니다(textLabel과 detailTextLabel로 구성되는 subtitle 스타일을 지정합니다).
        let cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "myCell")
        // 해당 셀에 출력할 폰트 이름을 추출합니다.
        let fontName = fontNameArray[indexPath.row]
        // 텍스트 레이블에 지정한 폰트로 샘플 문자를 출력합니다.
        cell.textLabel?.font = UIFont(name: fontName, size: 18)
        cell.textLabel?.text = "ABCDE abcde 012345 가나다라마"
        // 서브 텍스트 레이블에 폰트 이름을 출력합니다.
        cell.detailTextLabel?.textColor = UIColor.brown()
        cell.detailTextLabel?.text = fontName
        return cell
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}








