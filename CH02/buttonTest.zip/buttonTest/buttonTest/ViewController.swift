//
//  ViewController.swift
//  buttonTest
//
//  Created by YoonGahee on 2016. 7. 23..
//  Copyright © 2016년 myname. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myLabel: UILabel!

    @IBAction func tapBtn() {
        myLabel.text = "안녕하세요"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

